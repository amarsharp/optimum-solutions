package com.amar.solutions.controller;


import com.amar.solutions.entity.Address;
import com.amar.solutions.repository.AddressRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@Slf4j
@RestController
public class AddressController {


    @Autowired
    private AddressRepository addressRepository;

    @GetMapping(path="/address", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> getAddress() {
        return (List<Address>)addressRepository.findAll();
    }

    @GetMapping(path="/address/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getAddressById(@PathVariable String id) {
        Long addId = Long.parseLong(id);
        Optional<Address> addressOptional = addressRepository.findById(addId);

        if(!addressOptional.isPresent())
            return new ResponseEntity(HttpStatus.NOT_FOUND);

        return new ResponseEntity(addressOptional,HttpStatus.OK);
    }

    @DeleteMapping("/address/{id}")
    public ResponseEntity<Object> delete(@PathVariable String id) {
        Long addId = Long.parseLong(id);
        Optional<Address> addressOptional = addressRepository.findById(addId);

        if(!addressOptional.isPresent())
            return new ResponseEntity(HttpStatus.NOT_FOUND);

        addressRepository.deleteById(addId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @GetMapping("/address/count")
    public Long count() {
        return addressRepository.count();
    }

    @PutMapping(path="/address/{id}", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> createorUpdate(@RequestBody Address address, @PathVariable String id) {
        Long addId = Long.parseLong(id);
        Optional<Address> addressOptional = addressRepository.findById(addId);

        if(!addressOptional.isPresent())
            return new ResponseEntity(HttpStatus.NOT_FOUND);

        address.setId(addId);
        addressRepository.save(address);

        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping(path="/address", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> create(@RequestBody Address address) {
        addressRepository.save(address);
        return new ResponseEntity(HttpStatus.OK);
    }
}
