package com.amar.solutions.controller;

import com.amar.solutions.service.PushNotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Slf4j
@RestController
public class PushNotificationController {
    @Autowired
    PushNotificationService pushService;

    final List emitters = new CopyOnWriteArrayList<>();

    @GetMapping("/notification")
    public SseEmitter doNotify() throws InterruptedException, IOException {
        final SseEmitter emitter = new SseEmitter();
        pushService.addEmitter(emitter);
        pushService.doNotify();
        emitter.onCompletion(() -> pushService.removeEmitter(emitter));
        emitter.onTimeout(() -> {emitter.complete();pushService.removeEmitter(emitter);});
        return emitter;
    }
}
