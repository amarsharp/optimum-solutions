package com.amar.solutions.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name="T_ADDRESS")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String line1;
    private String line2;
    private String city;
    private String state;
    private int pin;
}
