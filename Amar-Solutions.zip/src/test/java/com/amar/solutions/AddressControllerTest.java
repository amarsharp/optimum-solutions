package com.amar.solutions;

import com.amar.solutions.entity.Address;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AddressControllerTest {

    @LocalServerPort
    private int randomServerPort;

    @Test
    public void testAddress() throws URISyntaxException
    {
        RestTemplate restTemplate=new RestTemplate();
        final String baseUrl = "http://localhost:" + randomServerPort + "/address";
        URI uri = new URI(baseUrl);

        ResponseEntity<Address[]> result = restTemplate.getForEntity(uri, Address[].class);
        Assert.assertEquals(200, result.getStatusCodeValue());
    }
}
